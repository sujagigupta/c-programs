//copy all elements of the array into another array


#include<stdio.h>
int
main ()
{
  int size, i;
  printf ("enter the size of array:");
  scanf ("%d", &size);
  int a[size], b[size];
  for (i = 0; i < size; i++)
    {
      printf ("enter the elements of array:");
      scanf ("%d", &a[i]);
    }
  for (i = 0; i < size; i++)
    a[i] == b[i];
  {
    printf ("elements of the original array:\n");
    for (i = 0; i < size; i++)
      printf ("%d", a[i]);
  }
  printf ("\n");
  {
    printf ("elements of the new array:");
    for (i = 0; i < size; i++)
      printf ("%d", b[i]);
  }
  return 0;
}

