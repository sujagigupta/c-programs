//find the sum of even number and product of odd number


#include<stdio.h>
int main()
{
 int size,i,sum=0,product=1;
 printf("enter the size of array:");
 scanf("%d",&size);
 int a[size];
 for(i=0;i<size;i++)
 {
printf("enter the elements of array:");
scanf("%d",&a[i]);
}
for(i=0;i<size;i++)
{
    if(a[i]%2==0)
    sum=sum+a[i];
    else
    product=product*a[i];
}
printf("\nsum of even=%d,product of odd=%d",sum,product);
return 0;
}
    
    
    
    
    
    

