// find maximum  and minimum element of array

#include<stdio.h>
int main ()
{
  int size, i, min,max;
  printf ("enter the size of array");
  scanf ("%d", &size);
  int a[size];
  for (i = 0; i < size; i++)
   { 
  printf ("enter the elements of array:");
  scanf ("%d", &a[i]);
   }
  for(i=0;i<size;i++)
  {
    if (min > a[i])
      min = a[i];
    if(max<a[i])
      max = a[i];
  }

  printf ("maximum element of this array:%d", max);
  printf ("\nminimum element of this aaray:%d", min);
  return 0;
}




