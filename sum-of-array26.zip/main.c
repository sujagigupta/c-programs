#include<stdio.h>
int
main ()
{
  int size, i,sum=0;
  printf ("enter the size of array:");
  scanf ("%d", &size);
  int a[size];
  for (i = 0; i < size; i++)
    {
      printf ("enter the elments of the array : ");
      scanf ("%d", &a[i]);
      sum=sum+a[i];
    }
    printf("the array is:  ");
  for (i = 0; i < size; i++)
   { printf ("%d\n",a[i]);
   }
  printf("sum of all the elements of  array=%d",sum);
    
  return 0;
}



