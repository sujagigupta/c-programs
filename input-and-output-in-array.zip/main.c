#include<stdio.h>
int main()
{
int a[10],i;
for(i=0;i<10;i++)
{
    printf("enter the values:");
    scanf("%d",&a[i]);
}
printf("array elements are:");
for(i=0;i<10;i++)
printf("%d",a[i]);
return 0;
}