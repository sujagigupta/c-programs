# assignment
This is my College Assignment of C language 
My self : Prakhar Singh .
Class: Btech CSE 1St Year .
Section :F-2 .
Roll No: 51 .
