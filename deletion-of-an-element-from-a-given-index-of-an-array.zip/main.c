#include<stdio.h>
int main()
{
    int size;
    printf("enter the size:");
    scanf("%d",&size);
    int a[size],i,position;
    for(i=0;i<size;i++)
   {
       printf("enter the element of array :");
        scanf("%d",&a[i]);
   }
   printf("enter position:");
   scanf("%d",&position);
   for(i=position;i<size;i++)
    {
        if(a[i]=a[i+1]);
    }
    for(i=0;i<size-1;i++)
    {
        printf("%d ",a[i]);
    }
    return 0;
}



