#include<stdio.h>
int
main ()
{
  int size;
  printf ("enter the size of array:");
  scanf ("%d", &size);
  int a[size], i, positive, negative;
  for (i = 0; i < size; i++)
    {
      printf ("enter the element of array%d\n", i + 1);
      scanf ("%d", &a[i]);
    }
  printf ("\npositive number are:");
  for (i = 0; i < size; i++)
    {
      if (a[i] > 0)
	{
	  printf ("\n%d", a[i]);
	}
    }
  printf ("\nnegative number are:");
  for (i = 0; i < size; i++)
    {
      if (a[i] < 0);
      {
	printf ("\n%d", a[i]);
      }
    }
  return 0;
}
