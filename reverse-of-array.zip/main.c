//reverse of array



#include<stdio.h>
int
main ()
{
    int size, i;
  printf ("enter the size of array:");
  scanf ("%d", &size);
  int a[size];
  for (i = 0; i <size; i++)
    {
      printf ("enter the elements of array:");
      scanf ("%d", &a[i]);

    }
  for (i =size-1; i>=0; i--)
    printf ("\n%d", a[i]);
  return 0;

}
