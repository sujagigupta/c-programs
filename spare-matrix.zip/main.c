#include<stdio.h>
int
main ()
{
  int m, n, i, j,count=0,odd=0;
  printf ("enter the number of rows:");
  scanf ("%d", &m);
  printf ("enter the number of col:");
  scanf ("%d", &n);
  int  a[m][n];
  for (i = 0; i < m; i++)
    {

      for (j = 0; j < n; j++)
	{
	  scanf ("%d",&a[i][j]);
	}

    }
  printf ("the matrix is:\n");
  for (i = 0; i < m; i++)
    {
      for (j = 0; j < n; j++)

	{
	  if (a[i][j] == 0)
	    count++;
	  else
	    odd++;
	}
    }
  if (count > odd)
    printf ("matrix is a spare matrix:");
  else
    printf ("matix is not a spare matrix:");
}
