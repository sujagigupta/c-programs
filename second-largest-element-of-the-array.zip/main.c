// find the second largest and the second smallest number in array

#include<stdio.h>
int main ()
{
    int size,i,max;
    printf("Enter the size of the array: ");
    scanf("%d",&size);
    int a[size];
    for(i=0;i<size;++i)
    {
        printf("Enter the elements in this array: ");
        scanf("%d",&a[i]);
    }
    for(i=0;i<size;++i)
    {
    if
max=a[i];
{
    printf("\n second largest element of this array:%d",a[i]);
}
   return 0;
}