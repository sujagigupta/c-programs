#include<stdio.h>
#include<string.h>
int main ()
{
    
    char name[50];
   
    fgets(name,50,stdin);
  printf ("string is:\n");
  puts(name);
    return 0;
    
}


