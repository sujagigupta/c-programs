#include<stdio.h>
int
main ()
{
  int i = 0;
  int marks[5];			//declaration of array
  marks[0] = 23;		// initialization of array
  marks[1] = 25;
  marks[2] = 28;
  marks[3] = 93;
  marks[4] = 63;
  for (i = 0; i < 5; i++)	//traversal of array
    {
      printf ("%d\n", marks[i]);
    }
  return 0;
}
