// count  total negative number in the array


#include<stdio.h>
int main()
{
 int size,i,count=0;
 printf("enter the size of array:");
 scanf("%d",&size);
 int a[size];
 for(i=0;i<size;i++)
 {
printf("enter the elements of array:");
scanf("%d",&a[i]);
}
for(i=0;i<size;i++)
{
    if(a[i]<0)
   count++; 
}
printf("\ntotal negative elements in array=%d",count);
return 0;
}
