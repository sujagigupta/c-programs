#include<stdio.h>
int main()
{
 int size,i,even=0,odd=0;
 printf("enter the size of array:");
 scanf("%d",&size);
 int a[size];
 for(i=0;i<size;i++)
 {
printf("enter the elements of array:");
scanf("%d",&a[i]);
}
for(i=0;i<size;i++)
{
    if(a[i]%2==0)
    even++;
    else
    odd++;
}
printf("\ntotal even=%d,total odd=%d",even,odd);
return 0;
}
    
    
    
    
    
    
