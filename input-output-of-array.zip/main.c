#include<stdio.h>
int main()
{
int size,i;
printf("enter the size of array:");
scanf("%d",&size);
int a[size];
for(i=0;i<size;i++)
{
printf("enter the values:");
scanf("%d",&a[i]);
}
for(i=0;i<size;i++)
printf("%d",a[i]);
return 0;
}
