// count the frequency of a given array

#include<stdio.h>
int
main ()
{
  int size;
  printf ("enter the size:");
  scanf ("%d", &size);
  int a[size], i, key, freq = 0;
  for (i = 0; i < size; i++)
   { printf ("enter the elements of the array:");
  scanf ("%d",& a[i]);
   }
    printf ("enter element to find frequency:");
    scanf ("%d", &key);
  
  for (i = 0; i < size; i++)
    if (a[i] == key)
      freq++;
  printf ("\n frequency of%d is%d", key, freq);
  return 0;
}
