#include<stdio.h>
int
main ()
{
  int m, n, i, j,c[m][n];
  printf ("enter the rows and col:");
  scanf ("%d%d", &m, &n);
  int a[m][n];
  for (i = 0; i < m; i++)
    for (j = 0; j < n; j++)
      {
	printf ("enter the values of first array:");
	scanf ("%d", &a[i][j]);
      }
       int b[m][n];
  for (i = 0; i < m; i++)
    for (j = 0; j < n; j++)
      {
	printf ("enter the values of second array:");
	scanf ("%d", &b[i][j]);
      }
  printf ("the  first matrix are:");
  for (i = 0; i < m; i++)
    {
      printf ("\n");
      for (j = 0; j < n; j++)
	printf ("%d\t", a[i][j]);

    }
    printf ("the  second matrix are:");
  for (i = 0; i < m; i++)
    {
      printf ("\n");
      for (j = 0; j < n; j++)
	printf ("%d\t", a[i][j]);
    }
	
      for(i=0;i<m;i++)
      for(j=0;j<n;j++)
      c[i][j]=a[i][j]+b[i][j];
      printf("\n addition of matrix is:");
      for(i=0;i<m;i++)
      {
          printf("\n");
          for(j=0;j<n;j++)
          printf("%d",c[i][j]);
      }
      return 0;
    }
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	














