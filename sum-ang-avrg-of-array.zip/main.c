//find the sum and avrg of the array
#include<stdio.h>
int main ()
{
    int size,i; 
    float sum=0,avrg;
    printf("Enter the size of the array: ");
    scanf("%d",&size);
    int a[size];
    for(i=0;i<size;i++)
    {
        printf("Enter the elements in this array: ");
        scanf("%d",&a[i]);
        sum+=a[i];
    }
    avrg=sum/size;
    printf("sum of all the elements of this array: %0.2f ",sum);
    printf("\navrg of all the elements of this array: %0.2f ",avrg);
    return 0;
}

