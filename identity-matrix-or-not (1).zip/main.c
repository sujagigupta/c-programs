#include<stdio.h>
int
main ()
{
  int m, n, i, j, flag = 0;
  printf ("enter the row and col:");
  scanf ("%d%d", &m, &n);
  int a[m][n];
  for (i = 0; i < m; i++)
    for (j = 0; j < n; j++)
      {
	printf ("enter the values of 2D matrix:");
	scanf ("%d", &a[i][j]);
      }
  printf ("the  first matrix is:");
  for (i = 0; i < m; i++)
    {
      printf ("\n");
      for (j = 0; j < n; j++)
	printf ("%d\t", a[i][j]);
    }
  int b[m][n];
  for (i = 0; i < m; i++)
    for (j = 0; j < n; j++)
      {
	printf ("enter the values of 2D matrix:");
	scanf ("%d", &b[i][j]);
      }
  printf ("the  second matrix is:");
  for (i = 0; i < m; i++)
    {
      printf ("\n");
      for (j = 0; j < n; j++)
	printf ("%d\t", b[i][j]);
    }
  for (i = 0; i < m; i++)
    for (j = 0; j < n; j++)
      {
	if (a[i][j] == b[i][j]);
	flag = 1;
      }
  if (flag == 0)
    printf ("\nthe matrix is identical:");
  else
    printf ("\n the matrix is not identical:");
  return 0;
}

















