#include<stdio.h>
int
main ()
{
  int m, n, i, j,sum;
  printf ("enter the rows and col:");
  scanf ("%d%d", &m, &n);
  int a[m][n];
  for (i = 0; i < m; i++)
    for (j = 0; j < n; j++)
      {
	printf ("enter the elements of array:");
	scanf ("%d", &a[i][j]);
      }
  printf ("the matrix are:");
  for (i = 0; i < m; i++)
    {
      printf ("\n");
      for (j = 0; j < n; j++)
	printf ("%d\t", a[i][j]);

    }
  for (i = 0; i < m; i++)
    {
      sum = 0;
      for (j = 0; j < n; j++)
	sum = sum + a[i][j];
      printf ("\n sum of row%d is %d", i + 1, sum);
    }
  for (i = 0; i < m; i++)
    {
      sum = 0;
      for (j = 0; j < n; j++)
	sum = sum + a[j][i];
      printf ("\n sum of col%d is %d", i + 1, sum);
    }
    return 0;
}
