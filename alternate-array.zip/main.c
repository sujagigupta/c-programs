//print alternate of array

#include<stdio.h>
int
main ()
{
  int size, i;
  printf ("enter the size of array:");
  scanf ("%d", &size);
  int a[size];
  for (i = 0; i < size; i++)
    {
      printf ("enter the elements of array:");
      scanf ("%d", &a[i]);
    }
  for (i = 0; i < size; i = i + 2)
    printf ("\n%d", a[i]);
  return 0;
}
