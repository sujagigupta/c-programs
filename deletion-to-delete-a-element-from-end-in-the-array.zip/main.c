#include<stdio.h>
int main()
{
    int size,i;
    printf("enter size:");
    scanf("%d",&size);
    int a[size];
    for(i=0;i<size;i++)
    {
        printf("enter the elements:");
    scanf("%d",&a[i]);
    }
        printf("\nthe array is:");
        for(i=0;i<size;i++)
        {
         printf("\n%d",a[i]);   
        }
        
            printf("the updated array:");
            for(i=0;i<size-1;i++)
        
        {
            printf("\n%d",a[i]);
        }
        return 0;
}