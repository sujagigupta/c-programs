//linear search of array


#include<stdio.h>
int
main ()
{
  int size;
  printf ("enter the size of array:");
  scanf ("%d", &size);
  int a[size], i, key, position, flag = 0;
  for (i = 0; i < size; i++)
    {
      printf ("enter the elements of an array:");
      scanf ("%d", &a[i]);
    }
  printf ("enter element to search:");
  scanf ("%d", &key);
  for (i = 0; i < size; i++)
    {
      if (a[i] == key)
	{
	  position = i + 1;
	  flag = 1;
	  break;
	}
    }
  if (flag == 1)
    printf ("\n number found at%dposition", position);
  else
    printf ("\n number not found:");
  return 0;
}
