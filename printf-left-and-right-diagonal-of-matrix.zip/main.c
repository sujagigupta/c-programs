#include<stdio.h>
int
main ()
{
  int m, n, i, j;
  printf ("enter the rows and col:");
  scanf ("%d%d", &m, &n);
  int a[m][n];
  for (i = 0; i < m; i++)
    for (j = 0; j < n; j++)
      {
	printf ("enter the elements of array:");
	scanf ("%d", &a[i][j]);
      }
  printf ("the matrix are:");
  for (i = 0; i < m; i++)
    {
      printf ("\n");
      for (j = 0; j < n; j++)
	printf ("%d\t", a[i][j]);

    }
  {
    printf ("the left diagonal is:");
    for (i = 0; i < m; i++)
      for (j = 0; j < n; j++)
	if (i == j)
	  printf ("%d\t", a[i][j]);
      
  }
	  {
	    printf ("the right diagonal are:");
	    for (i = 0; i < m; i++)
	      for (j = 0; j < n; j++)
		if (i + j == 2)
		  printf ("%d\t", a[i][j]);
	  }
    return 0;
  }
