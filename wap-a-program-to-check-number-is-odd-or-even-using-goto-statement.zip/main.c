#include<stdio.h>
int main()
{
    int a;
    printf("the number is:");
    scanf("%d",&a);
    if(a%2==0)
    goto even;
    else
    goto odd;
    even:
    printf("\n number is even:");
    return 0;
    odd:
    printf("\n number is odd:");
    return 0;
    
}